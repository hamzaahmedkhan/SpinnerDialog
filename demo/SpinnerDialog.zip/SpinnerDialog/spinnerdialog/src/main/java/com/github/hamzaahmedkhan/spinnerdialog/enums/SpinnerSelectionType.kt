package com.github.hamzaahmedkhan.spinnerdialog.enums

enum class SpinnerSelectionType {
    SINGLE_SELECTION, MULTI_SELECTION
}